package tools

var CommitID = ""
var BuildTime = ""
