# OpenRASP remote management tool

This repository contains source code for OpenRASP backend API server. For more information please referer to [https://rasp.baidu.com](https://rasp.baidu.com)
