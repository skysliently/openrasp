//Copyright 2017-2019 Baidu Inc.
//
//Licensed under the Apache License, Version 2.0 (the "License");
//you may not use this file except in compliance with the License.
//You may obtain a copy of the License at
//
//http: //www.apache.org/licenses/LICENSE-2.0
//
//Unless required by applicable law or agreed to in writing, software
//distributed under the License is distributed on an "AS IS" BASIS,
//WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
//See the License for the specific language governing permissions and
//limitations under the License.

package main

import (
	_ "rasp-cloud/environment"
	_ "rasp-cloud/models"
	_ "rasp-cloud/filter"
	_ "rasp-cloud/controllers"
	"github.com/astaxie/beego"
	"rasp-cloud/controllers"
	"rasp-cloud/routers"
	"rasp-cloud/environment"
)

func main() {
	beego.BConfig.Listen.Graceful = true
	routers.InitRouter()
	beego.ErrorController(&controllers.ErrorController{})
	if environment.StartBeego {
		beego.Run()
	}
}
